public class RoofQuote {
    public static void main(String[] args) {
        //Get the cost per square foot
        //Create a Variable named shingleCost that can store a double (ex 3.99 -> decimal point value)
        double shingleCost = 3.99;
//        System.out.println(shingleCost);
//        shingleCost = 2.99;
//        System.out.println(shingleCost);
        //Get the size of the roof (in square feet)
        double customerRoof = 892.22;
        //Get the installation cost per sqft
        double installationCost = 2.99;
        //Calculate and output the total
        System.out.println(shingleCost*customerRoof*installationCost);
    }
}
