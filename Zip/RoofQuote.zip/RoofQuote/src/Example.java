public class Example {
    public static void main(String[] args) {
        int number = 5;
        double number2 = 5.0;
        String phrase = "Good better best never let it rest";
        String name = "Cai Filiault";
        char playAgain = 'Y';
        System.out.println(phrase);
    }
}
