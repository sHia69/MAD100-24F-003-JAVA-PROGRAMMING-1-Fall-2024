package com.fxexample.firstfx;

public class Minion  extends Employee{
    boolean cyclops;

    public boolean isCyclops() {
        return cyclops;
    }

    public void setCyclops(boolean cyclops) {
        this.cyclops = cyclops;
    }
}
